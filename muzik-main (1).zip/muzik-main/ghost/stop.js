const { MessageEmbed } = require("discord.js");

exports.run = async (client, message, args) => { 
    const channel = message.member.voice.channel
    if (!channel)return message.channel.send("Üzgünüm ama müzik çalmak için bir ses kanalında olmanız gerekiyor!", message.channel);
    const serverQueue = message.client.queue.get(message.guild.id);
    if (!serverQueue)return message.channel.send("Senin için durdurabileceğim hiçbir şey yok!", message.channel);
   if(!serverQueue.connection)return
if(!serverQueue.connection.dispatcher)return
     try{
      serverQueue.connection.dispatcher.end();
      } catch (error) {
        message.guild.me.voice.channel.leave();
        message.client.queue.delete(message.guild.id);
        returnmessage.channel.send(`:notes: Oyuncu durdu ve sıra temizlendi.: ${error}`, message.channel);
      }
    message.client.queue.delete(message.guild.id);
    serverQueue.songs = [];
    message.react("✅")
};
    exports.help = { name:"stop", aliases: ["durdur"] };