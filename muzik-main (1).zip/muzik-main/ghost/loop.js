const { MessageEmbed } = require("discord.js");

exports.run = async (client, message, args) => {

    const serverQueue = message.client.queue.get(message.guild.id);
       if (serverQueue) {
            serverQueue.loop = !serverQueue.loop;
            return message.channel.send({
                embed: {
                    color: "#5865f2",
                    description: `🔁  **|**  Döngü **\`${serverQueue.loop === true ? "açıldı" : "kapandı"}\`**`
                }
            });
        };
    return message.channel.send("Bu sunucuda hiçbir şey oynatılmıyor.", message.channel);
};

exports.help = { name: "loop", aliases: ["tekrarla"] }