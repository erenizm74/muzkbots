const { MessageEmbed } = require("discord.js");

exports.run = async (client, message, args) => {

    const channel = message.member.voice.channel
    if (!channel)return sendError("Üzgünüm ama müzik çalmak için bir ses kanalında olmanız gerekiyor!");
    const serverQueue = message.client.queue.get(message.guild.id);
    if (!serverQueue)return sendError("Senin için atlayabileceğim hiçbir şey yok");
        if(!serverQueue.connection)return
if(!serverQueue.connection.dispatcher)return
     if (serverQueue && !serverQueue.playing) {
      serverQueue.playing = true;
      serverQueue.connection.dispatcher.resume();
      let xd = new MessageEmbed()
      .setDescription(" ▶ Müziği sizin için atladım!")
      .setColor("#5865f2")
      .setTitle("Müzik atlandı!")
       
   return message.channel.send(xd).catch(err => console.log(err));
      
    }


       try{
      serverQueue.connection.dispatcher.end()
      } catch (error) {
        serverQueue.voiceChannel.leave()
        message.client.queue.delete(message.guild.id);
        return sendError(`:notes: Oyuncu durdu ve sıra temizlendi.: ${error}`, message.channel);
      }
    message.react("✅")

    function sendError(text) {
      return message.channel.send(new MessageEmbed().setDescription(text)      .setColor("RED")
      .setTitle("Hata!"))
    }
};

exports.help = { name:"atla", aliases: ["skip"] };